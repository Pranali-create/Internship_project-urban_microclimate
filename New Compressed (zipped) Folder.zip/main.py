﻿import cv2
import geocoder
import random
import folium
import webbrowser
import os

# --- Step 1: Get location using webcam (face detection triggers location fetch) ---
def get_location_with_webcam():
    cap = cv2.VideoCapture(0)
    face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_frontalface_default.xml")

    print("📷 Turn on your webcam... Looking for face to detect location...")

    location = None
    while True:
        ret, frame = cap.read()
        if not ret:
            break

        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        faces = face_cascade.detectMultiScale(gray, 1.3, 5)

        for (x, y, w, h) in faces:
            # Draw rectangle around face
            cv2.rectangle(frame, (x,y), (x+w,y+h), (255,0,0), 2)
            if location is None:
                g = geocoder.ip("me")  # get current location
                if g.ok:
                    location = g.latlng
                    print(f"📍 Location detected: {location}")
        
        cv2.imshow("Webcam - Press Q to exit", frame)

        if cv2.waitKey(1) & 0xFF == ord("q") or location is not None:
            break

    cap.release()
    cv2.destroyAllWindows()
    return location

# --- Step 2: Generate simulated weather data ---
def generate_weather():
    return {
        "Rain (mm)": round(random.uniform(0, 100), 2),
        "Sun (hrs)": round(random.uniform(0, 12), 1),
        "Wind (km/h)": round(random.uniform(0, 50), 1),
        "Wetness (%)": round(random.uniform(0, 100), 1)
    }

# --- Step 3: Create and open map ---
def create_map(lat, lon, weather):
    m = folium.Map(location=[lat, lon], zoom_start=10)

    weather_info = "<br>".join([f"{k}: {v}" for k, v in weather.items()])
    folium.Marker(
        location=[lat, lon],
        popup=f"<b>Weather Data</b><br>{weather_info}",
        tooltip="📍 Your Location"
    ).add_to(m)

    map_file = "indian_weather_map.html"
    m.save(map_file)

    # Open automatically
    webbrowser.open("file://" + os.path.realpath(map_file))
    print(f"✅ Map opened in browser with weather info!")

# --- Main flow ---
if __name__ == "__main__":
    location = get_location_with_webcam()
    if location:
        lat, lon = location
        weather = generate_weather()
        print("🌦️ Weather values:", weather)
        create_map(lat, lon, weather)
    else:
        print("❌ Could not detect location.")
