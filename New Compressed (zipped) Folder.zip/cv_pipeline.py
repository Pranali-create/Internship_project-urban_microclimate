import cv2
import random

def analyze_frame(frame):
    """
    Analyze a webcam frame to detect simple conditions.
    (Right now still fake, but we use frame data.)
    """
    if frame is None:
        return "unknown"

    # Example: check average brightness
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    avg_brightness = gray.mean()

    if avg_brightness > 180:
        return "sunny"
    elif avg_brightness > 100:
        return "cloudy"
    else:
        # Random choice between rainy/windy if dark
        return random.choice(["rainy", "windy"])
