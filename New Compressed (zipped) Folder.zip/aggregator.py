def aggregate_results(results):
    """
    Collect multiple webcam analyses and return summary.
    """
    summary = {}
    for condition in results:
        summary[condition] = summary.get(condition, 0) + 1
    return summary
